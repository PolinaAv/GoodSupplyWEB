﻿$(function () {
    $('[data-user-menu]').hover(function () {
        $('[data-user-menu]').toggleClass('open');
    })
});